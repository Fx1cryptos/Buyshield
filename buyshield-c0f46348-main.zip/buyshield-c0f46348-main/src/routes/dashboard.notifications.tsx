import { createFileRoute } from "@tanstack/react-router";
import { EmptyPage } from "@/components/dashboard/EmptyPage";
import { Bell } from "lucide-react";

export const Route = createFileRoute("/dashboard/notifications")({
  head: () => ({ meta: [{ title: "Notifications — BuyShield" }] }),
  component: () => <EmptyPage title="Notifications" description="Real-time updates on your protected transactions." icon={Bell} />,
});
