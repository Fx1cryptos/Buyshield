import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  Shield, Lock, CheckCircle2, ArrowRight, Sparkles, Package, Wallet,
  BadgeCheck, Scale, Bell, Truck, Bot, Star, ChevronDown, Zap, Users, Globe,
} from "lucide-react";
import { SiteNav } from "@/components/site/SiteNav";
import { SiteFooter } from "@/components/site/SiteFooter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LogoMark } from "@/components/brand/Logo";
import { useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "BuyShield — Every Purchase, Protected." },
      { name: "description", content: "BuyShield is a trusted escrow platform that securely holds payments until buyers confirm they received exactly what they ordered." },
      { property: "og:title", content: "BuyShield — Every Purchase, Protected." },
      { property: "og:description", content: "Trusted escrow for online transactions. Buy and sell with confidence." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Landing,
});

const fadeUp = {
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-80px" },
  transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] as const },
};

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <SiteNav />
      <Hero />
      <Marquee />
      <Features />
      <HowItWorks />
      <Benefits />
      <Testimonials />
      <Pricing />
      <FAQ />
      <CTA />
      <SiteFooter />
    </div>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden pt-32 pb-24 sm:pt-40 sm:pb-32">
      <div className="absolute inset-0 bg-mesh opacity-70" />
      <div className="absolute inset-x-0 top-0 -z-10 h-[600px] bg-[image:var(--gradient-hero)]" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="mx-auto max-w-3xl text-center"
        >
          <Badge variant="secondary" className="mb-6 gap-1.5 rounded-full border bg-background/60 px-3 py-1.5 backdrop-blur">
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            <span className="text-xs font-medium">Now protecting $2.4B+ in transactions</span>
          </Badge>
          <h1 className="text-balance text-5xl font-bold tracking-tight text-foreground sm:text-6xl md:text-7xl">
            Buy Online <span className="text-gradient">Without Fear.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-muted-foreground">
            BuyShield protects every online purchase by securely holding payments in escrow
            until buyers receive exactly what they ordered — in the condition they expected.
          </p>
          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button size="lg" asChild className="h-12 rounded-full bg-gradient-to-r from-primary to-[color:var(--primary-glow)] px-8 shadow-glow transition hover:opacity-95">
              <Link to="/register">
                Get Started <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="h-12 rounded-full px-8">
              <a href="#how">Learn More</a>
            </Button>
          </div>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
            {[
              { icon: Lock, label: "Bank-grade encryption" },
              { icon: BadgeCheck, label: "Verified accounts" },
              { icon: Shield, label: "100% money-back" },
            ].map((i) => (
              <div key={i.label} className="flex items-center gap-2">
                <i.icon className="h-4 w-4 text-primary" />
                <span>{i.label}</span>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.2 }}
          className="relative mx-auto mt-20 max-w-5xl"
        >
          <div className="absolute -inset-4 rounded-3xl bg-gradient-to-r from-primary/30 to-[color:var(--primary-glow)]/30 blur-2xl" />
          <div className="glass relative rounded-3xl border p-2 shadow-elegant">
            <div className="rounded-2xl bg-card p-6 sm:p-8">
              <DashboardPreview />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function DashboardPreview() {
  return (
    <div className="grid gap-4 md:grid-cols-3">
      <div className="md:col-span-2 rounded-2xl border bg-background p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs uppercase tracking-wider text-muted-foreground">Protected Balance</p>
            <p className="mt-1 font-display text-4xl font-bold">$12,480.<span className="text-2xl text-muted-foreground">50</span></p>
          </div>
          <Badge className="bg-success/10 text-success hover:bg-success/20">+18.2%</Badge>
        </div>
        <div className="mt-6 flex h-32 items-end gap-1.5">
          {[40, 65, 45, 80, 55, 90, 70, 95, 60, 85, 100, 78].map((h, i) => (
            <div key={i} className="flex-1 rounded-t-md bg-gradient-to-t from-primary/40 to-primary/80" style={{ height: `${h}%` }} />
          ))}
        </div>
      </div>
      <div className="space-y-3">
        {[
          { name: "MacBook Pro 16\"", status: "In Escrow", color: "bg-primary/10 text-primary" },
          { name: "Vintage Rolex", status: "Delivered", color: "bg-success/10 text-success" },
          { name: "Art Print #12", status: "Shipping", color: "bg-warning/10 text-warning" },
        ].map((o) => (
          <div key={o.name} className="flex items-center justify-between rounded-xl border bg-background p-3">
            <div className="flex items-center gap-3">
              <div className="grid h-9 w-9 place-items-center rounded-lg bg-secondary">
                <Package className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="text-sm font-medium">{o.name}</p>
                <p className="text-xs text-muted-foreground">Order #{Math.floor(Math.random() * 9000 + 1000)}</p>
              </div>
            </div>
            <Badge className={`${o.color} hover:${o.color} text-xs`}>{o.status}</Badge>
          </div>
        ))}
      </div>
    </div>
  );
}

function Marquee() {
  const items = ["Stripe", "Shopify", "Airbnb", "Notion", "Linear", "Ramp", "Vercel", "Figma"];
  return (
    <section className="border-y bg-secondary/30 py-8">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <p className="mb-6 text-center text-xs font-medium uppercase tracking-widest text-muted-foreground">
          Trusted by teams at world-class companies
        </p>
        <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-4 opacity-60">
          {items.map((n) => (
            <span key={n} className="font-display text-xl font-semibold tracking-tight text-muted-foreground">{n}</span>
          ))}
        </div>
      </div>
    </section>
  );
}

const features = [
  { icon: Lock, title: "Secure Escrow", desc: "Payments are held in segregated accounts and released only when both parties are satisfied." },
  { icon: Shield, title: "Buyer Protection", desc: "Get a full refund if the item never arrives or isn't as described. No questions asked." },
  { icon: BadgeCheck, title: "Seller Protection", desc: "Get paid guaranteed once delivery is confirmed. No chargebacks. No surprises." },
  { icon: Users, title: "Verified Accounts", desc: "Every account passes KYC + identity verification before transacting." },
  { icon: Scale, title: "Dispute Resolution", desc: "Expert mediators resolve conflicts fairly in under 72 hours." },
  { icon: Truck, title: "Shipment Tracking", desc: "Real-time updates from checkout to delivery, integrated with 200+ carriers." },
  { icon: Bell, title: "Real-time Alerts", desc: "Instant notifications on every status change via email, SMS, and push." },
  { icon: Bot, title: "AI Fraud Detection", desc: "Machine learning models flag suspicious activity before it costs you.", soon: true },
];

function Features() {
  return (
    <section id="features" className="py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div {...fadeUp} className="mx-auto max-w-2xl text-center">
          <Badge variant="secondary" className="rounded-full">Features</Badge>
          <h2 className="mt-4 text-4xl font-bold tracking-tight sm:text-5xl">
            Everything you need to <span className="text-gradient">transact safely</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            A complete escrow stack purpose-built for modern commerce.
          </p>
        </motion.div>
        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              {...fadeUp}
              transition={{ ...fadeUp.transition, delay: i * 0.05 }}
              className="group relative overflow-hidden rounded-2xl border bg-card p-6 transition hover:shadow-elegant hover:-translate-y-1"
            >
              <div className="mb-4 grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-primary to-[color:var(--primary-glow)] text-primary-foreground shadow-glow">
                <f.icon className="h-5 w-5" />
              </div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-semibold">{f.title}</h3>
                {f.soon && <Badge variant="outline" className="text-[10px]">Soon</Badge>}
              </div>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

const steps = [
  { n: "01", icon: Wallet, title: "Buyer deposits funds", desc: "Payment is placed in a secure BuyShield escrow account, not sent to the seller yet." },
  { n: "02", icon: Truck, title: "Seller ships the item", desc: "Once notified, the seller ships with tracked delivery. Every step is logged." },
  { n: "03", icon: CheckCircle2, title: "Buyer confirms delivery", desc: "Buyer inspects and approves. Only then does BuyShield release funds to the seller." },
];

function HowItWorks() {
  return (
    <section id="how" className="relative py-24 sm:py-32">
      <div className="absolute inset-0 bg-mesh opacity-40" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div {...fadeUp} className="mx-auto max-w-2xl text-center">
          <Badge variant="secondary" className="rounded-full">How it works</Badge>
          <h2 className="mt-4 text-4xl font-bold tracking-tight sm:text-5xl">Three steps to safer commerce</h2>
          <p className="mt-4 text-lg text-muted-foreground">Simple for buyers and sellers, engineered for trust.</p>
        </motion.div>
        <div className="relative mt-16 grid gap-8 md:grid-cols-3">
          <div className="pointer-events-none absolute left-0 right-0 top-16 hidden h-px bg-gradient-to-r from-transparent via-border to-transparent md:block" />
          {steps.map((s, i) => (
            <motion.div key={s.n} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.1 }} className="relative">
              <div className="glass relative flex h-14 w-14 items-center justify-center rounded-2xl border shadow-soft">
                <s.icon className="h-6 w-6 text-primary" />
                <span className="absolute -right-2 -top-2 grid h-6 w-6 place-items-center rounded-full bg-navy text-[10px] font-bold text-white">{s.n}</span>
              </div>
              <h3 className="mt-6 text-xl font-semibold">{s.title}</h3>
              <p className="mt-2 text-muted-foreground">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

const benefits = [
  { icon: Zap, stat: "72h", label: "Average dispute resolution" },
  { icon: Globe, stat: "180+", label: "Countries supported" },
  { icon: Users, stat: "500K+", label: "Protected transactions" },
  { icon: Shield, stat: "$2.4B", label: "Funds safely escrowed" },
];

function Benefits() {
  return (
    <section className="py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-navy p-10 text-white shadow-elegant sm:p-16">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-4xl font-bold tracking-tight sm:text-5xl">Built for scale. Trusted globally.</h2>
            <p className="mt-4 text-white/70">Backed by numbers that speak louder than promises.</p>
          </div>
          <div className="mt-14 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {benefits.map((b, i) => (
              <motion.div key={b.label} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.08 }} className="text-center">
                <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-white/10">
                  <b.icon className="h-5 w-5" />
                </div>
                <p className="mt-4 font-display text-4xl font-bold">{b.stat}</p>
                <p className="mt-1 text-sm text-white/60">{b.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

const testimonials = [
  { quote: "BuyShield transformed how our marketplace handles payouts. Chargebacks dropped 94% in the first quarter.", name: "Sarah Chen", role: "COO, Vintage Market" },
  { quote: "As a high-value collectibles seller, I finally sleep at night. The buyer never fails to release funds because they trust the process.", name: "Marcus Reeves", role: "Independent Dealer" },
  { quote: "The dispute resolution team is world-class. Fair, fast, and always well-documented. It's the standard we've been waiting for.", name: "Priya Anand", role: "Head of Trust, ArtCollect" },
];

function Testimonials() {
  return (
    <section className="py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div {...fadeUp} className="mx-auto max-w-2xl text-center">
          <Badge variant="secondary" className="rounded-full">Testimonials</Badge>
          <h2 className="mt-4 text-4xl font-bold tracking-tight sm:text-5xl">Loved by buyers and sellers</h2>
        </motion.div>
        <div className="mt-16 grid gap-6 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <motion.figure
              key={t.name}
              {...fadeUp}
              transition={{ ...fadeUp.transition, delay: i * 0.08 }}
              className="flex flex-col justify-between rounded-2xl border bg-card p-8 shadow-soft"
            >
              <div>
                <div className="flex gap-0.5">
                  {Array.from({ length: 5 }).map((_, k) => <Star key={k} className="h-4 w-4 fill-warning text-warning" />)}
                </div>
                <blockquote className="mt-4 text-pretty text-foreground">"{t.quote}"</blockquote>
              </div>
              <figcaption className="mt-6 flex items-center gap-3 border-t pt-6">
                <div className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-primary to-[color:var(--primary-glow)] text-sm font-semibold text-white">
                  {t.name.split(" ").map(n => n[0]).join("")}
                </div>
                <div>
                  <p className="text-sm font-semibold">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.role}</p>
                </div>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}

const tiers = [
  { name: "Starter", price: "1.9%", desc: "For occasional sellers", features: ["Up to $5k / month", "Standard support", "Basic dispute resolution"] },
  { name: "Business", price: "1.4%", featured: true, desc: "For growing merchants", features: ["Unlimited volume", "Priority support", "Advanced dispute + mediation", "Team accounts"] },
  { name: "Enterprise", price: "Custom", desc: "For platforms & marketplaces", features: ["Volume pricing", "Dedicated manager", "White-label API", "SLA & compliance"] },
];

function Pricing() {
  return (
    <section id="pricing" className="py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div {...fadeUp} className="mx-auto max-w-2xl text-center">
          <Badge variant="secondary" className="rounded-full">Pricing</Badge>
          <h2 className="mt-4 text-4xl font-bold tracking-tight sm:text-5xl">
            Simple, transparent pricing
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">Only pay when a transaction completes. Full pricing launches soon.</p>
        </motion.div>
        <div className="mt-16 grid gap-6 md:grid-cols-3">
          {tiers.map((t, i) => (
            <motion.div
              key={t.name}
              {...fadeUp}
              transition={{ ...fadeUp.transition, delay: i * 0.08 }}
              className={`relative rounded-2xl border p-8 ${t.featured ? "bg-navy text-white shadow-elegant" : "bg-card"}`}
            >
              {t.featured && (
                <Badge className="absolute -top-3 right-8 bg-gradient-to-r from-primary to-[color:var(--primary-glow)] text-white">Most popular</Badge>
              )}
              <h3 className="text-lg font-semibold">{t.name}</h3>
              <p className={`mt-1 text-sm ${t.featured ? "text-white/60" : "text-muted-foreground"}`}>{t.desc}</p>
              <p className="mt-6 font-display text-5xl font-bold">
                {t.price}
                {t.price !== "Custom" && <span className={`ml-1 text-base font-normal ${t.featured ? "text-white/60" : "text-muted-foreground"}`}>/ txn</span>}
              </p>
              <ul className="mt-8 space-y-3">
                {t.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm">
                    <CheckCircle2 className={`h-4 w-4 ${t.featured ? "text-primary-glow" : "text-primary"}`} />
                    {f}
                  </li>
                ))}
              </ul>
              <Button
                asChild
                className={`mt-8 w-full rounded-full ${t.featured ? "bg-white text-navy hover:bg-white/90" : ""}`}
                variant={t.featured ? "default" : "outline"}
              >
                <Link to="/register">Get started</Link>
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

const faqs = [
  { q: "How does BuyShield protect my money?", a: "Funds are held in a segregated, FDIC-insured escrow account. Sellers only get paid once you confirm delivery and satisfaction." },
  { q: "What if the item never arrives?", a: "You get a full refund. Our automated system tracks shipments and initiates refunds if delivery fails or is disputed successfully." },
  { q: "How long does dispute resolution take?", a: "Most disputes resolve within 72 hours. Complex cases may take up to 7 days with a dedicated mediator." },
  { q: "Is BuyShield a marketplace?", a: "No. BuyShield is escrow infrastructure. You continue selling and buying wherever you like — we just secure the payment." },
  { q: "What are the fees?", a: "1.4% – 1.9% per successful transaction, depending on your plan. No monthly fees. No hidden costs." },
];

function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="py-24 sm:py-32">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <motion.div {...fadeUp} className="text-center">
          <Badge variant="secondary" className="rounded-full">FAQ</Badge>
          <h2 className="mt-4 text-4xl font-bold tracking-tight sm:text-5xl">Questions, answered.</h2>
        </motion.div>
        <div className="mt-12 space-y-3">
          {faqs.map((f, i) => (
            <motion.div key={f.q} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.04 }} className="overflow-hidden rounded-2xl border bg-card">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="flex w-full items-center justify-between p-6 text-left"
              >
                <span className="font-medium">{f.q}</span>
                <ChevronDown className={`h-5 w-5 shrink-0 text-muted-foreground transition-transform ${open === i ? "rotate-180" : ""}`} />
              </button>
              {open === i && (
                <div className="px-6 pb-6 text-muted-foreground">{f.a}</div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="pb-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary via-primary to-[color:var(--primary-glow)] p-12 text-center text-white shadow-glow sm:p-20">
          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "radial-gradient(circle at 20% 20%, white 1px, transparent 1px)", backgroundSize: "24px 24px" }} />
          <div className="relative">
            <LogoMark className="justify-center [&_span]:text-white" />
            <h2 className="mt-6 text-4xl font-bold tracking-tight sm:text-5xl">Ready to transact fearlessly?</h2>
            <p className="mx-auto mt-4 max-w-xl text-white/80">Join hundreds of thousands protecting their online purchases with BuyShield.</p>
            <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
              <Button size="lg" asChild className="h-12 rounded-full bg-white px-8 text-primary hover:bg-white/90">
                <Link to="/register">Create free account</Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="h-12 rounded-full border-white/40 bg-transparent px-8 text-white hover:bg-white/10 hover:text-white">
                <Link to="/dashboard">View demo</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
