import { createFileRoute } from "@tanstack/react-router";
import { EmptyPage } from "@/components/dashboard/EmptyPage";
import { Package } from "lucide-react";

export const Route = createFileRoute("/dashboard/orders")({
  head: () => ({ meta: [{ title: "Protected Orders — BuyShield" }] }),
  component: () => <EmptyPage title="Protected Orders" description="Every order you've protected with BuyShield escrow." icon={Package} />,
});
