import { createFileRoute } from "@tanstack/react-router";
import { EmptyPage } from "@/components/dashboard/EmptyPage";
import { Settings } from "lucide-react";

export const Route = createFileRoute("/dashboard/settings")({
  head: () => ({ meta: [{ title: "Settings — BuyShield" }] }),
  component: () => <EmptyPage title="Settings" description="Preferences, security, and workspace configuration." icon={Settings} />,
});
