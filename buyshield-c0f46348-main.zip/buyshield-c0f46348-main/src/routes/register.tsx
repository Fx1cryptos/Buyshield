import { createFileRoute, Link } from "@tanstack/react-router";
import { AuthShell } from "@/components/auth/AuthShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/register")({
  head: () => ({ meta: [{ title: "Create account — BuyShield" }] }),
  component: RegisterPage,
});

function RegisterPage() {
  return (
    <AuthShell
      title="Create your account"
      subtitle="Start protecting every purchase in under a minute."
      footer={<>Already have an account? <Link to="/login" className="font-medium text-primary hover:underline">Sign in</Link></>}
    >
      <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <Label htmlFor="first">First name</Label>
            <Input id="first" className="mt-1.5 h-11" />
          </div>
          <div>
            <Label htmlFor="last">Last name</Label>
            <Input id="last" className="mt-1.5 h-11" />
          </div>
        </div>
        <div>
          <Label htmlFor="email">Work email</Label>
          <Input id="email" type="email" placeholder="you@company.com" className="mt-1.5 h-11" />
        </div>
        <div>
          <Label htmlFor="password">Password</Label>
          <Input id="password" type="password" className="mt-1.5 h-11" />
          <p className="mt-1 text-xs text-muted-foreground">Minimum 8 characters with a number and symbol.</p>
        </div>
        <Button asChild className="h-11 w-full rounded-full bg-gradient-to-r from-primary to-[color:var(--primary-glow)]">
          <Link to="/verify-email">Create account</Link>
        </Button>
        <p className="text-center text-xs text-muted-foreground">
          By continuing you agree to our <a href="#" className="underline">Terms</a> and <a href="#" className="underline">Privacy Policy</a>.
        </p>
      </form>
    </AuthShell>
  );
}
