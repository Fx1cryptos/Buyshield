import { createFileRoute } from "@tanstack/react-router";
import { EmptyPage } from "@/components/dashboard/EmptyPage";
import { Wallet } from "lucide-react";

export const Route = createFileRoute("/dashboard/wallet")({
  head: () => ({ meta: [{ title: "Wallet — BuyShield" }] }),
  component: () => <EmptyPage title="Wallet" description="Manage your balance, deposits, and withdrawals." icon={Wallet} />,
});
