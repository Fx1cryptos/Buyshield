import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  ArrowUpRight, Wallet, Package, ShieldCheck, TrendingUp, Truck,
  CheckCircle2, Clock, AlertTriangle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/dashboard/")({
  head: () => ({ meta: [{ title: "Overview — BuyShield" }] }),
  component: Overview,
});

const stats = [
  { label: "Wallet Balance", value: "$12,480.50", change: "+18.2%", icon: Wallet, tone: "text-success" },
  { label: "Active Escrows", value: "8", change: "+2 this week", icon: ShieldCheck, tone: "text-primary" },
  { label: "Protected Orders", value: "142", change: "+12", icon: Package, tone: "text-primary" },
  { label: "Completed", value: "1,248", change: "+18.2%", icon: CheckCircle2, tone: "text-success" },
];

const orders = [
  { id: "ORD-8842", item: "MacBook Pro 16\" M3", seller: "TechDealer", amount: "$2,499.00", status: "In Escrow", stage: 2 },
  { id: "ORD-8841", item: "Vintage Rolex Submariner", seller: "LuxuryWatches", amount: "$8,750.00", status: "Shipping", stage: 3 },
  { id: "ORD-8840", item: "Art Print — Basquiat Repro", seller: "GalleryOne", amount: "$320.00", status: "Delivered", stage: 4 },
  { id: "ORD-8839", item: "Herman Miller Chair", seller: "OfficeSurplus", amount: "$1,199.00", status: "Disputed", stage: 3 },
  { id: "ORD-8838", item: "Canon R5 Body", seller: "PhotoPro", amount: "$3,899.00", status: "Completed", stage: 4 },
];

const statusStyle: Record<string, string> = {
  "In Escrow": "bg-primary/10 text-primary",
  "Shipping": "bg-warning/10 text-warning",
  "Delivered": "bg-success/10 text-success",
  "Completed": "bg-success/10 text-success",
  "Disputed": "bg-destructive/10 text-destructive",
};

function Overview() {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Welcome back, Jordan</h1>
          <p className="mt-1 text-sm text-muted-foreground">Here's what's happening across your protected transactions.</p>
        </div>
        <Button className="rounded-full bg-gradient-to-r from-primary to-[color:var(--primary-glow)] shadow-glow">
          <Package className="mr-2 h-4 w-4" /> New Protected Transaction
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="rounded-2xl border bg-card p-6 shadow-soft"
          >
            <div className="flex items-center justify-between">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary">
                <s.icon className="h-5 w-5" />
              </div>
              <span className={`inline-flex items-center gap-1 text-xs font-medium ${s.tone}`}>
                <TrendingUp className="h-3 w-3" /> {s.change}
              </span>
            </div>
            <p className="mt-4 text-xs uppercase tracking-wider text-muted-foreground">{s.label}</p>
            <p className="mt-1 font-display text-3xl font-bold">{s.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-2xl border bg-card p-6 shadow-soft">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">Escrow activity</h2>
              <p className="text-sm text-muted-foreground">Last 30 days</p>
            </div>
            <Badge variant="secondary" className="rounded-full">+24% vs prev</Badge>
          </div>
          <div className="mt-6 flex h-56 items-end gap-2">
            {[40, 55, 45, 70, 62, 80, 68, 85, 72, 92, 78, 88, 95, 82, 100, 90, 76, 84].map((h, i) => (
              <div key={i} className="group relative flex-1">
                <div
                  className="w-full rounded-t-md bg-gradient-to-t from-primary/60 to-primary transition-all group-hover:from-primary group-hover:to-[color:var(--primary-glow)]"
                  style={{ height: `${h}%` }}
                />
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border bg-card p-6 shadow-soft">
          <h2 className="text-lg font-semibold">Transaction timeline</h2>
          <p className="text-sm text-muted-foreground">MacBook Pro 16"</p>
          <ol className="mt-6 space-y-4">
            {[
              { icon: CheckCircle2, label: "Funds deposited", time: "3 days ago", done: true },
              { icon: CheckCircle2, label: "Seller accepted", time: "2 days ago", done: true },
              { icon: Truck, label: "Shipped via FedEx", time: "1 day ago", done: true, active: true },
              { icon: Clock, label: "Awaiting delivery", time: "Est. tomorrow", done: false },
              { icon: ShieldCheck, label: "Release payment", time: "Pending", done: false },
            ].map((s, i, arr) => (
              <li key={i} className="relative flex gap-3">
                {i < arr.length - 1 && <div className="absolute left-[15px] top-8 h-full w-px bg-border" />}
                <div className={`relative z-10 grid h-8 w-8 shrink-0 place-items-center rounded-full ${
                  s.done ? "bg-primary text-primary-foreground" : "border bg-background text-muted-foreground"
                }`}>
                  <s.icon className="h-4 w-4" />
                </div>
                <div className="flex-1 pb-1">
                  <p className={`text-sm font-medium ${s.active ? "text-primary" : ""}`}>{s.label}</p>
                  <p className="text-xs text-muted-foreground">{s.time}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>

      <div className="rounded-2xl border bg-card shadow-soft">
        <div className="flex items-center justify-between p-6">
          <div>
            <h2 className="text-lg font-semibold">Recent orders</h2>
            <p className="text-sm text-muted-foreground">Your protected transactions.</p>
          </div>
          <Button variant="ghost" size="sm" className="gap-1">View all <ArrowUpRight className="h-3.5 w-3.5" /></Button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead className="border-y bg-secondary/40 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-6 py-3 text-left font-medium">Order</th>
                <th className="px-6 py-3 text-left font-medium">Item</th>
                <th className="px-6 py-3 text-left font-medium">Seller</th>
                <th className="px-6 py-3 text-right font-medium">Amount</th>
                <th className="px-6 py-3 text-left font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {orders.map((o) => (
                <tr key={o.id} className="transition hover:bg-secondary/30">
                  <td className="px-6 py-4 font-mono text-xs text-muted-foreground">{o.id}</td>
                  <td className="px-6 py-4 font-medium">{o.item}</td>
                  <td className="px-6 py-4 text-muted-foreground">{o.seller}</td>
                  <td className="px-6 py-4 text-right font-semibold">{o.amount}</td>
                  <td className="px-6 py-4">
                    <Badge className={`${statusStyle[o.status]} hover:${statusStyle[o.status]} rounded-full`}>
                      {o.status === "Disputed" && <AlertTriangle className="mr-1 h-3 w-3" />}
                      {o.status}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
