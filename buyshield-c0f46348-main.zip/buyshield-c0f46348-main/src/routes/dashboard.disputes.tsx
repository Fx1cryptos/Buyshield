import { createFileRoute } from "@tanstack/react-router";
import { EmptyPage } from "@/components/dashboard/EmptyPage";
import { Scale } from "lucide-react";

export const Route = createFileRoute("/dashboard/disputes")({
  head: () => ({ meta: [{ title: "Disputes — BuyShield" }] }),
  component: () => <EmptyPage title="Disputes" description="Open, track, and resolve transaction disputes." icon={Scale} />,
});
