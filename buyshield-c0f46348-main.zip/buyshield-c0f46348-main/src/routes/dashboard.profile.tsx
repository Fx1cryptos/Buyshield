import { createFileRoute } from "@tanstack/react-router";
import { EmptyPage } from "@/components/dashboard/EmptyPage";
import { User } from "lucide-react";

export const Route = createFileRoute("/dashboard/profile")({
  head: () => ({ meta: [{ title: "Profile — BuyShield" }] }),
  component: () => <EmptyPage title="Profile" description="Your identity, verification, and public reputation." icon={User} />,
});
