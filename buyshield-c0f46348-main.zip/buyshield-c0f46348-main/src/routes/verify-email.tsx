import { createFileRoute, Link } from "@tanstack/react-router";
import { AuthShell } from "@/components/auth/AuthShell";
import { Button } from "@/components/ui/button";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { MailCheck } from "lucide-react";

export const Route = createFileRoute("/verify-email")({
  head: () => ({ meta: [{ title: "Verify email — BuyShield" }] }),
  component: VerifyPage,
});

function VerifyPage() {
  return (
    <AuthShell
      title="Verify your email"
      subtitle="We sent a 6-digit code to your inbox. Enter it below to continue."
    >
      <div className="mb-6 flex items-center gap-3 rounded-xl border bg-secondary/50 p-3">
        <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
          <MailCheck className="h-5 w-5" />
        </div>
        <div className="text-sm">
          <p className="font-medium">Check your inbox</p>
          <p className="text-muted-foreground">Code expires in 10 minutes.</p>
        </div>
      </div>
      <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
        <div className="flex justify-center">
          <InputOTP maxLength={6}>
            <InputOTPGroup>
              {Array.from({ length: 6 }).map((_, i) => <InputOTPSlot key={i} index={i} className="h-12 w-12 text-lg" />)}
            </InputOTPGroup>
          </InputOTP>
        </div>
        <Button asChild className="h-11 w-full rounded-full bg-gradient-to-r from-primary to-[color:var(--primary-glow)]">
          <Link to="/dashboard">Verify & continue</Link>
        </Button>
        <p className="text-center text-sm text-muted-foreground">Didn't get it? <button className="font-medium text-primary hover:underline">Resend</button></p>
      </form>
    </AuthShell>
  );
}
