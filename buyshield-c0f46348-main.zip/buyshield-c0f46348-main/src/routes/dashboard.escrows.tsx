import { createFileRoute } from "@tanstack/react-router";
import { EmptyPage } from "@/components/dashboard/EmptyPage";
import { ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/dashboard/escrows")({
  head: () => ({ meta: [{ title: "Active Escrows — BuyShield" }] }),
  component: () => <EmptyPage title="Active Escrows" description="Live transactions currently held in escrow." icon={ShieldCheck} />,
});
