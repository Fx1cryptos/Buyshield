export const LOGO_CID = "bafybeid5wshamuhxzalh6gprxsiuh2f7gpg3p3vb4mo545jyq7e7rj43eu";
export const LOGO_URL = `https://ipfs.io/ipfs/${LOGO_CID}`;

export function Logo({ className = "h-8 w-8" }: { className?: string }) {
  return (
    <img
      src={LOGO_URL}
      alt="BuyShield"
      className={className}
      loading="eager"
    />
  );
}

export function LogoMark({ withText = true, className = "" }: { withText?: boolean; className?: string }) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <Logo className="h-8 w-8 rounded-lg" />
      {withText && (
        <span className="font-display text-lg font-bold tracking-tight text-foreground">
          BuyShield
        </span>
      )}
    </div>
  );
}
