import { createFileRoute } from "@tanstack/react-router";
import { Package } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export function EmptyPage({ title, description, icon: Icon = Package }: { title: string; description: string; icon?: LucideIcon }) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{description}</p>
      </div>
      <div className="grid place-items-center rounded-2xl border border-dashed bg-card p-16 text-center">
        <div className="grid h-14 w-14 place-items-center rounded-2xl bg-primary/10 text-primary">
          <Icon className="h-6 w-6" />
        </div>
        <p className="mt-4 font-semibold">Nothing here yet</p>
        <p className="mt-1 max-w-sm text-sm text-muted-foreground">
          This section is ready to plug into the BuyShield API. Data will appear here as soon as your workspace has activity.
        </p>
      </div>
    </div>
  );
}

export const makeStubRoute = (path: string, title: string, description: string, icon?: LucideIcon) =>
  createFileRoute(path as any)({
    head: () => ({ meta: [{ title: `${title} — BuyShield` }] }),
    component: () => <EmptyPage title={title} description={description} icon={icon} />,
  });
