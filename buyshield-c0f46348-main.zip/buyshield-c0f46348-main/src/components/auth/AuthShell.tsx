import { Link } from "@tanstack/react-router";
import { LogoMark } from "@/components/brand/Logo";
import { ShieldCheck } from "lucide-react";
import type { ReactNode } from "react";

export function AuthShell({
  title,
  subtitle,
  children,
  footer,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-2">
      <div className="flex flex-col justify-between px-6 py-8 sm:px-10">
        <Link to="/">
          <LogoMark />
        </Link>
        <div className="mx-auto w-full max-w-md py-16">
          <h1 className="text-3xl font-bold tracking-tight">{title}</h1>
          {subtitle && <p className="mt-2 text-muted-foreground">{subtitle}</p>}
          <div className="mt-8">{children}</div>
          {footer && <div className="mt-6 text-center text-sm text-muted-foreground">{footer}</div>}
        </div>
        <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} BuyShield, Inc.</p>
      </div>
      <div className="relative hidden overflow-hidden bg-navy lg:block">
        <div className="absolute inset-0 bg-mesh opacity-40" />
        <div className="relative flex h-full flex-col justify-between p-12 text-white">
          <div className="glass inline-flex w-fit items-center gap-2 rounded-full border-white/20 bg-white/10 px-3 py-1.5 text-xs">
            <ShieldCheck className="h-3.5 w-3.5" />
            Trusted escrow platform
          </div>
          <div>
            <blockquote className="text-2xl font-medium leading-snug tracking-tight">
              "BuyShield made our high-value transactions feel effortless. It's the trust layer the internet has been missing."
            </blockquote>
            <div className="mt-6 flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-full bg-white/10 font-semibold">SC</div>
              <div>
                <p className="text-sm font-semibold">Sarah Chen</p>
                <p className="text-xs text-white/60">COO, Vintage Market</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
